const yesBtn = document.querySelector('.yes-btn');
const noBtn = document.querySelector('.no-btn');
const questionContainer = document.querySelector('.question-container');
const resultContainer = document.querySelector('.result-container');

noBtn.addEventListener('mouseover', () => {
  const x = Math.random() * 200 - 100;
  const y = Math.random() * 100 - 50;
  noBtn.style.transform = `translate(${x}px, ${y}px)`;
});

yesBtn.addEventListener('click', () => {
  questionContainer.classList.add('hidden');
  resultContainer.classList.remove('hidden');
});